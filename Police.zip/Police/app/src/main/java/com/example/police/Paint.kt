package com.example.police

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Paint : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_paint)
    }
}